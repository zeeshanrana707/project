from flask import Flask, render_template, request, jsonify
import pandas as pd
import pickle

app = Flask(__name__)

# Load data
df = pd.read_csv("Training.csv")

# Clean dataset
df = df.loc[:, ~df.columns.str.contains("^Unnamed")]

# Separate features and target
X = df.drop("prognosis", axis=1)
y = df["prognosis"]

symptoms = list(X.columns)

# Load model
model = pickle.load(open("model_svc.pkl", "rb"))

# ✅ Get common symptoms (most frequent)
common_symptoms = list(X.sum().sort_values(ascending=False).head(20).index)


@app.route("/")
def home():
    return render_template("index.html", symptoms=common_symptoms)


# 🔥 Dynamic filtering API
@app.route("/filter", methods=["POST"])
def filter_symptoms():
    data = request.get_json()
    selected = data.get("selected", [])

    filtered_df = df.copy()

    for symptom in selected:
        if symptom in filtered_df.columns:
            filtered_df = filtered_df[filtered_df[symptom] == 1]

    # Remaining symptoms
    remaining_symptoms = (
        filtered_df.drop("prognosis", axis=1)
        .sum()
        .loc[lambda x: x > 0]
        .index.tolist()
    )

    remaining_symptoms = [s for s in remaining_symptoms if s not in selected]

    # Possible diseases
    possible_diseases = filtered_df["prognosis"].value_counts().head(5).index.tolist()

    return jsonify({
        "symptoms": remaining_symptoms,
        "diseases": possible_diseases
    })

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()
        selected = data.get("selected", [])

        if not selected:
            return jsonify({"error": "No symptoms selected"})

        input_vector = [0] * len(X.columns)

        for symptom in selected:
            if symptom in X.columns:
                index = list(X.columns).index(symptom)
                input_vector[index] = 1

        pred = model.predict([input_vector])[0]

        try:
            prob = model.predict_proba([input_vector])[0]
            confidence = round(max(prob) * 100, 2)
        except:
            confidence = 0

        return jsonify({
    "disease": str(pred),   # ensures string
    "confidence": float(confidence)
})

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)